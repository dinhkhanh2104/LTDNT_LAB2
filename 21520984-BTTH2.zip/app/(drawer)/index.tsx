// import { Stack } from 'expo-router';
// import { View, Text, StyleSheet } from 'react-native';

// export default function Home() {
//   return (
//     <>
//       <Stack.Screen options={{ title: 'Home' }} />
//       <View style = {styles.container}>
//         <Text style = {styles.bold}>Home la alala</Text>
//       </View>
//     </>
//   );
// }


// const styles = StyleSheet.create({
//     container: {
//         flex: 1
//     },
//     bold: {
//         fontWeight: "bold"
//     }
// })
