import { Link, Slot } from 'expo-router';

const DrawerLayout = () => <Slot />;

export default DrawerLayout;
