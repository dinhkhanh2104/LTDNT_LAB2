/* eslint-disable */
import * as Router from 'expo-router';

export * from 'expo-router';

declare module 'expo-router' {
  export namespace ExpoRouter {
    export interface __routes<T extends string = string> extends Record<string, unknown> {
      StaticRoutes: `/` | `/(drawer)` | `/(drawer)/` | `/(drawer)/authen` | `/(drawer)/authen/` | `/(drawer)/authen/(tabs)` | `/(drawer)/authen/(tabs)/` | `/(drawer)/authen/(tabs)/categories` | `/(drawer)/authen/(tabs)/favorite` | `/(drawer)/authen/(tabs)/profile` | `/(drawer)/authen/authProvider` | `/(drawer)/authen/categories` | `/(drawer)/authen/favorite` | `/(drawer)/authen/login` | `/(drawer)/authen/profile` | `/(drawer)/authen/signup` | `/(drawer)/facebook` | `/(drawer)/facebook/` | `/(drawer)/feedback` | `/(drawer)/feedback/` | `/_sitemap` | `/authen` | `/authen/` | `/authen/(tabs)` | `/authen/(tabs)/` | `/authen/(tabs)/categories` | `/authen/(tabs)/favorite` | `/authen/(tabs)/profile` | `/authen/authProvider` | `/authen/categories` | `/authen/favorite` | `/authen/login` | `/authen/profile` | `/authen/signup` | `/facebook` | `/facebook/` | `/feedback` | `/feedback/` | `/modal`;
      DynamicRoutes: never;
      DynamicRouteTemplate: never;
    }
  }
}
